"""Constants for the Wiser by Feller integration."""

DOMAIN = "wiser_by_feller"
DEFAULT_API_USER = "homeassistant"
DEFAULT_IMPORT_USER = "admin"
MANUFACTURER = "Feller by Schneider Electric"
CONF_IMPORTUSER = "import_user"
# Marker stored when the import user is unknown (e.g. for entries created before
# the import user was persisted). Distinguishes "we don't know" from a real user.
IMPORT_USER_UNKNOWN = "<unknown>"
OPTIONS_ALLOW_MISSING_GATEWAY_DATA = "allow_missing_gateway_data"
HA_BLUE = "#1abcf2"
LED_OFF_COLOR = "#000000"
MIN_FIRMWARE_BUTTON_LED_OVERRIDE = (6, 0, 41)
# foreground_color / background_color on the device input config. Note that
# the physical device also needs firmware 2.8.2-0 or newer for it to take
# effect (https://github.com/Feller-AG/wiser-api/blob/main/CHANGELOG.md).
MIN_FIRMWARE_STATUS_LIGHT_COLOR_OFF = (6, 0, 41)
MIN_FIRMWARE_MANAGED_BUTTONS = (6, 0, 42)
MIN_FIRMWARE_REFRESH_PROPERTIES = (6, 0, 40)

EVENT_BUTTON = f"{DOMAIN}_button_event"

# Physical position of each button on a front, by number of button inputs.
# Buttons are numbered down the left column first, then down the right column,
# and a rocker (up/down) occupies a single channel. Fronts with a different
# number of buttons report no position.
POSITION_SINGLE = "single"
POSITION_LEFT = "left"
POSITION_RIGHT = "right"
POSITION_TOP_LEFT = "top_left"
POSITION_BOTTOM_LEFT = "bottom_left"
POSITION_TOP_RIGHT = "top_right"
POSITION_BOTTOM_RIGHT = "bottom_right"

BUTTON_POSITIONS: dict[int, tuple[str, ...]] = {
    1: (POSITION_SINGLE,),
    2: (POSITION_LEFT, POSITION_RIGHT),
    3: (POSITION_LEFT, POSITION_TOP_RIGHT, POSITION_BOTTOM_RIGHT),
    4: (
        POSITION_TOP_LEFT,
        POSITION_BOTTOM_LEFT,
        POSITION_TOP_RIGHT,
        POSITION_BOTTOM_RIGHT,
    ),
}

# C-block hardware type categories (bits 9-14 of the C-block firmware ID, see
# aiowiserbyfeller.util.parse_wiser_device_fwid) whose front module name fully
# describes the device. For these, the actuator module name is omitted from the
# device name, e.g. "Touch Thermostat" instead of
# "Touch Thermostat (Thermostat Nebenstelle)".
SELF_DESCRIBING_FRONT_HW_TYPES = {
    0x09,  # Touch display fronts
}
